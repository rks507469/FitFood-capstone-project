package ahmux.nutritionpoint;

public interface FragmentsCommunicator {

    void respond(String data1, int data2);

}
